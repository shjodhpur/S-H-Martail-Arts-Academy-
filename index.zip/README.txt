S H Martial Arts & Self Defense Academy - Static Website

Contents:
- index.html
- styles.css
- coach.jpg (placeholder)
- gallery1.jpg .. gallery4.jpg (placeholders)

How to use:
1. Unzip the folder.
2. Replace coach.jpg and gallery images with your real photos (keep the same filenames), or update paths.
3. Upload the folder to Netlify using drag & drop, or host on any static web host.

WhatsApp buttons use: https://wa.me/919782342112 with a preset message.

If you want a React version or help deploying to Netlify, ask me and I'll provide step-by-step instructions.
